/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.notepad1;

/**
 *
 * @author ABS
 */
public class myapp {
    public static void main(String [] args){
    
    Notepad1 notp=new Notepad1();
}
    
}
